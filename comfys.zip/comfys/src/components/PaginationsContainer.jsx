import { useLoaderData } from "react-router-dom";
import { paginationAmount } from "../utils";
import { useState } from "react";
function PaginationsContainer() {
  const { meta } = useLoaderData();
  const paginate = meta.pagination.pageCount;
  const nextPage = meta.pagination.page;
  console.log(nextPage);
  console.log(paginate);
  const [page, setPage] = useState(nextPage)

  const handlePage = (newPage) => {
    const son =  newPage === 1 ? 2 :1
    setPage(son)
  }

  return (
    <div>
      <div className=" flex justify-end join mt-8 pb-6 ml-auto">
      <button className="btn mr-2 shadow-xl hover:shadow-2xl transition duration-300 ">Previous page</button>
        <button className=" " onChange={() => page(handlePage)}>
          {paginationAmount(paginate)}
        </button>
      <button className=" btn  shadow-xl hover:shadow-2xl duration-300 ">Next</button>
      </div>
    </div>
  );
}

export default PaginationsContainer;